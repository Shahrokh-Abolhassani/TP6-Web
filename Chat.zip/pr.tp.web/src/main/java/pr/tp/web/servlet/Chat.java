package pr.tp.web.servlet;

import java.io.IOException;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/chat")
public class Chat extends HttpServlet {
	private static final long serialVersionUID = 197811968639586823L;
	private StringBuffer chatContent;

	@Override
	public void init() throws ServletException {

		chatContent = new StringBuffer();

		chatContent.append("Bienvenue sur le chat.  ");

		chatContent.append("Soyez gentils.").append("\n");
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RequestDispatcher rd = request.getRequestDispatcher("chat.jsp");
		RequestDispatcher rd2 = request.getRequestDispatcher("chat2.jsp");

		request.setAttribute("content", chatContent.toString());
		request.setAttribute("content2", chatContent.toString());
		rd.include(request, response);
		rd2.include(request, response);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String a = req.getParameter("ligne");
		String b = req.getParameter("ligne2");
		HttpSession session3 = req.getSession();
		HttpSession session4 = req.getSession();
		if (a != null) {

			Date time = new Date();

			String Name1 = (String) session3.getAttribute("UserName1");
			chatContent.append("(" + time.toString() + "): ").append(Name1 + " >>").append(req.getParameter("ligne"))
					.append("\n");
		} else if (b != null) {
			Date time = new Date();

			String Name2 = (String) session4.getAttribute("UserName2");
			chatContent.append("(" + time.toString() + "): ").append(Name2 + " >>").append(req.getParameter("ligne2"))
					.append("\n");

		}
		String refresh = req.getParameter("refresh");
		if (refresh != null) {
			int start = 0;
			int end = 1000;
			chatContent.delete(start, end);

		}

		doGet(req, resp);
	}

}
